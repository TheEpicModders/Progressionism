package com.progressionism.registry;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ProgressionismBlocks {

    public static final String MODID = "progressionism";

    public static final class_2960 TIN_ORE_ID = class_2960.method_60655(MODID, "tin_ore");
    public static final class_2960 DEEPSLATE_TIN_ORE_ID = class_2960.method_60655(MODID, "deepslate_tin_ore");
    public static final class_2960 TIN_BLOCK_ID = class_2960.method_60655(MODID, "tin_block");
    public static final class_2960 RAW_TIN_BLOCK_ID = class_2960.method_60655(MODID, "raw_tin_block");

    public static final class_5321<class_2248> TIN_ORE_KEY = class_5321.method_29179(class_7924.field_41254, TIN_ORE_ID);
    public static final class_5321<class_2248> DEEPSLATE_TIN_ORE_KEY = class_5321.method_29179(class_7924.field_41254, DEEPSLATE_TIN_ORE_ID);
    public static final class_5321<class_2248> TIN_BLOCK_KEY = class_5321.method_29179(class_7924.field_41254, TIN_BLOCK_ID);
    public static final class_5321<class_2248> RAW_TIN_BLOCK_KEY = class_5321.method_29179(class_7924.field_41254, RAW_TIN_BLOCK_ID);

    public static final class_5321<class_1792> TIN_ORE_ITEM_KEY = class_5321.method_29179(class_7924.field_41197, TIN_ORE_ID);
    public static final class_5321<class_1792> DEEPSLATE_TIN_ORE_ITEM_KEY = class_5321.method_29179(class_7924.field_41197, DEEPSLATE_TIN_ORE_ID);
    public static final class_5321<class_1792> TIN_BLOCK_ITEM_KEY = class_5321.method_29179(class_7924.field_41197, TIN_BLOCK_ID);
    public static final class_5321<class_1792> RAW_TIN_BLOCK_ITEM_KEY = class_5321.method_29179(class_7924.field_41197, RAW_TIN_BLOCK_ID);

    public static final class_2248 TIN_ORE = new class_2248(
            class_4970.class_2251.method_9637()
                    .method_9629(2.5F, 3.0F)
                    .method_29292()
                    .method_9626(class_2498.field_11544)
                    .method_63500(TIN_ORE_KEY)
    );
    public static final class_2248 DEEPSLATE_TIN_ORE = new class_2248(
            class_4970.class_2251.method_9637()
                    .method_9629(3.5F, 3.0F)
                    .method_29292()
                    .method_9626(class_2498.field_29033)
                    .method_63500(DEEPSLATE_TIN_ORE_KEY)
    );
    public static final class_2248 TIN_BLOCK = new class_2248(
            class_4970.class_2251.method_9637()
                    .method_9629(4.0F, 6.0F)
                    .method_29292()
                    .method_9626(class_2498.field_55794)
                    .method_63500(TIN_BLOCK_KEY)
    );
    public static final class_2248 RAW_TIN_BLOCK = new class_2248(
            class_4970.class_2251.method_9637()
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_55794)
                    .method_63500(RAW_TIN_BLOCK_KEY)

    );

    public static void registerItems() {

        class_2378.method_39197(class_7923.field_41175, TIN_ORE_KEY, TIN_ORE);
        class_2378.method_39197(class_7923.field_41175, DEEPSLATE_TIN_ORE_KEY, DEEPSLATE_TIN_ORE);
        class_2378.method_39197(class_7923.field_41175, TIN_BLOCK_KEY, TIN_BLOCK);
        class_2378.method_39197(class_7923.field_41175, RAW_TIN_BLOCK_KEY, RAW_TIN_BLOCK);

        class_1792.class_1793 itemSettings = new class_1792.class_1793()
                .method_63686(TIN_ORE_ITEM_KEY)
                .method_63685();
        class_1792.class_1793 itemSettings_1 = new class_1792.class_1793()
                .method_63686(DEEPSLATE_TIN_ORE_ITEM_KEY)
                .method_63685();
        class_1792.class_1793 itemSettings_2 = new class_1792.class_1793()
                .method_63686(TIN_BLOCK_ITEM_KEY)
                .method_63685();
        class_1792.class_1793 itemSettings_3 = new class_1792.class_1793()
                .method_63686(RAW_TIN_BLOCK_ITEM_KEY)
                .method_63685();

        class_1747 blockItem = new class_1747(TIN_ORE, itemSettings);
        class_1747 blockItem2 = new class_1747(DEEPSLATE_TIN_ORE, itemSettings_1);
        class_1747 blockItem3 = new class_1747(TIN_BLOCK, itemSettings_2);
        class_1747 blockItem4 = new class_1747(RAW_TIN_BLOCK, itemSettings_3);

        class_2378.method_39197(class_7923.field_41178, TIN_ORE_ITEM_KEY, blockItem);
        class_2378.method_39197(class_7923.field_41178, DEEPSLATE_TIN_ORE_ITEM_KEY, blockItem2);
        class_2378.method_39197(class_7923.field_41178, TIN_BLOCK_ITEM_KEY, blockItem3);
        class_2378.method_39197(class_7923.field_41178, RAW_TIN_BLOCK_ITEM_KEY, blockItem4);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743)
                .register(entries -> {
                    entries.addAfter(class_1802.field_29022, blockItem);
                    entries.addAfter(ProgressionismBlocks.TIN_ORE, blockItem2);
                    entries.addAfter(class_1802.field_33507, blockItem4);
                });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195)
                .register(entries -> {
                    entries.method_45421(blockItem3);
                });
    }
}